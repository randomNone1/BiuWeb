<?php
/**
* CBLib, Community Builder Library(TM)
* @version $Id: 6/20/14 12:25 AM $
* @copyright (C) 2004-2015 www.joomlapolis.com / Lightning MultiCom SA - and its licensors, all rights reserved
* @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU/GPL version 2
*/


defined('CBLIB') or die();

/**
 * Snoopy Class implementation
 * @deprecated CB 1.2.2 : use CBSnoopy for 1-to-1 replacement
 */
class Snoopy extends CBSnoopy
{
}
