<?php
namespace GuzzleHttp\Command\Exception;

/**
 * Exception encountered when a 5xx level response is received for a request
 */
class CommandServerException extends CommandException {}
