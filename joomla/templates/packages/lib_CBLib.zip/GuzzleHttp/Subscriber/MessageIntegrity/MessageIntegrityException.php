<?php
namespace GuzzleHttp\Subscriber\MessageIntegrity;

use GuzzleHttp\Exception\RequestException;

class MessageIntegrityException extends RequestException {}
