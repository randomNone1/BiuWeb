Structure of CBLib 2.0:


to use CBLib 2.0:

// This activates the autoloader which gives access to all CBLib classes at once:

include_once 'libraries/CBLib/CB/Application/CBApplication.php';
\CB\Application\CBApplication::init();
echo CBLib\Core\CBLib::execute();


Structure:

AhaWow: All the awesome XML stuff

Cms: CMS access library: No direct access to CMS API or database outside of this library! That way we have portability accross versions and platforms
  `--- Joomla3: Main Joomla interface for Joomla 3.x
  `--- Joomla2: Joomla 2.5 interface (derives from Joomla3)
  - Class Cms: allows to get the right CMS object

Core: That's where the basic stuff happens: this is where the core CBLib namespace lives
  `--- Class Application: Represents the instance being executed, and gives access to the Config, the Input, Output, Session and Logger, has the main execute method.
  `--- Class AutoLoader: No need to touch for now, as all magic happens inside automatically, except if you need to add auto-loading paths
  `--- Class Dispatcher: Handles a CBLib\input request and returns the corresponding CBLib\Output, using CBLib\Router and invoking a CBLib\Controller

Guzzle: The Guzzle 4.1.6 library adapted to work on PHP 5.3+
  Documentation:
  - http://docs.guzzlephp.org/en/guzzle4/index.html
  Doc of components:
  - http://docs.guzzlephp.org/en/guzzle4/index.html#http-components
    - https://github.com/guzzle/log-subscriber
    - https://github.com/guzzle/oauth-subscriber
    - https://github.com/guzzle/progress-subscriber
    - https://github.com/guzzle/retry-subscriber
    - https://github.com/guzzle/message-integrity-subscriber
  - http://docs.guzzlephp.org/en/guzzle4/index.html#service-description-commands
    - https://github.com/guzzle/command
    - https://github.com/guzzle/guzzle-services
  - http://docs.guzzlephp.org/en/guzzle4/streams.html
  Source: (all adaptations have been forked to https://github.com/beat/ into branches on-php-5-3):
  - https://github.com/guzzle/guzzle/tree/master
  - https://github.com/guzzle/log-subscriber
  - https://github.com/guzzle/oauth-subscriber
  - https://github.com/guzzle/progress-subscriber
  - https://github.com/guzzle/retry-subscriber
  - https://github.com/guzzle/message-integrity-subscriber
  - https://github.com/guzzle/command
  - https://github.com/guzzle/guzzle-services
  - https://github.com/guzzle/streams
